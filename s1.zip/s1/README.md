# Coding-Raja-Technologies-Internship
it is basic food ordering website using css, html, javascript 
